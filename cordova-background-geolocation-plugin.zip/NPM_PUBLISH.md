# Publicar el plugin en npm y actualizar desde GitHub

Este fork está preparado para publicarse en npm como **paquete con scope** (`@josuelmm/cordova-background-geolocation`), porque el nombre sin scope ya está usado en npm por otro publicador.

## 1. Cuenta en npm

1. Crea una cuenta en [npmjs.com](https://www.npmjs.com/signup) si no tienes.
2. El **nombre de usuario en npm** debe coincidir con el scope del `package.json` (`josuelmm`).  
   Si tu usuario en npm es otro, cambia en `package.json` la línea:
   ```json
   "name": "@TU_NPM_USER/cordova-background-geolocation"
   ```
3. **Requisito para publicar:** npm exige **autenticación de dos factores (2FA)** o un **token granular con "bypass 2FA"** para publicar paquetes. Sin esto obtendrás `403 Forbidden` al hacer `npm publish`.

   **Opción A – Activar 2FA (recomendado):**
   - En [npmjs.com](https://www.npmjs.com/) → tu avatar → **Account settings** → **Enable 2FA** (o "Add two-factor authentication").
   - Sigue el flujo (app de autenticación o SMS). Luego podrás publicar con `npm login` + `npm publish`.

   **Opción B – Token Automation (permite publicar sin tener 2FA):**
   - En [npmjs.com](https://www.npmjs.com/) → **Access Tokens** → **Generate New Token**.
   - Elige **Automation** (no "Publish" ni "Read and Publish": esos siguen exigiendo 2FA).
   - Copia el token. Para publicar desde la terminal:
     ```bash
     npm config set //registry.npmjs.org/:_authToken=TU_TOKEN_AQUI
     npm publish --access public
     ```
   - Para GitHub Actions, guarda el mismo token como secret `NPM_TOKEN`.

## 2. Publicación manual (primera vez)

Desde la raíz del proyecto:

```bash
npm login
npm publish --access public
```

- Si tienes 2FA activada, npm te pedirá el código de la app/SMS tras usuario y contraseña.
- Solo la primera publicación del paquete con scope necesita `--access public`; las siguientes pueden ser `npm publish`.

**Sobre el aviso de `.npmignore`:** Si ves "No .npmignore file found, using .gitignore", puedes ignorarlo: el proyecto tiene `.npmignore` en la raíz y el tarball se genera bien. Si quieres silenciar el aviso, asegúrate de estar en la raíz del repo al ejecutar `npm publish`.

## 3. Probar localmente (Angular y tarball)

Antes de publicar puedes comprobar que el build de Angular y el paquete se generan bien.

### Compilar solo Angular

Desde la raíz del proyecto:

```bash
npm run build:angular
```

Genera los `.js` y `.d.ts` en la carpeta `angular/` (es lo mismo que ejecuta el workflow al publicar).

### Crear el .tgz localmente (sin publicar en npm)

```bash
npm pack
```

- Ejecuta **prepack** (que llama a `build:angular`) y **crea un archivo `.tgz` en la raíz del proyecto** (la carpeta donde ejecutaste el comando).
- **Nombre del archivo:** `josuelmm-cordova-background-geolocation-<versión>.tgz` (p. ej. `josuelmm-cordova-background-geolocation-3.0.2.tgz`). Al final del comando npm muestra la ruta del archivo creado.
- Para ver solo la lista de archivos **sin** crear el `.tgz`: `npm pack --dry-run`.

### Probar el paquete en otra app

En un proyecto Ionic/Capacitor o Cordova, instala el `.tgz` que generaste (usa la ruta real a tu plugin):

```bash
npm install D:\xampp\htdocs\cordova-background-geolocation-plugin\josuelmm-cordova-background-geolocation-3.0.2.tgz
npx cap sync
```

Luego en la app puedes usar el plugin global o, en Angular, importar desde `@josuelmm/cordova-background-geolocation/angular` y comprobar que compila y funciona.

## 4. Publicación automática al crear un Release en GitHub

Cada vez que **crees un Release** en tu repositorio de GitHub, el workflow publicará esa versión en npm.

### Configurar el token de npm en GitHub

1. En [npmjs.com](https://www.npmjs.com/) → tu perfil → **Access Tokens** → **Generate New Token**.
2. Elige tipo **Automation** (recomendado) o **Publish**.
3. Copia el token (solo se muestra una vez).
4. En tu repo de GitHub: **Settings** → **Secrets and variables** → **Actions** → **New repository secret**.
5. Nombre: `NPM_TOKEN`, valor: el token de npm.

### Crear un release y publicar en npm

1. Sube los cambios y asegúrate de que la versión en `package.json` y en `plugin.xml` sea la que quieres publicar.
2. En GitHub: **Releases** → **Create a new release**.
3. Elige la rama (p. ej. `main`) y crea un **tag** nuevo (p. ej. `v2.3.4`) o usa uno existente.
4. Rellena título y descripción (puedes copiar del CHANGELOG).
5. Pulsa **Publish release**.
6. El workflow **Publish to npm** se ejecutará y publicará en npm; puedes ver el progreso en la pestaña **Actions**.

### Flujo resumido

```
Actualizas código → subes a GitHub → creas Release (con tag) → GitHub Actions publica en npm
```

No hace falta hacer push a una rama concreta para publicar; lo que dispara la publicación es **crear/publicar el Release**.

## 5. Instalación del plugin por los usuarios

Con el paquete con scope, la instalación es:

```bash
npm install @josuelmm/cordova-background-geolocation
npx cap sync
```

o con Cordova:

```bash
cordova plugin add @josuelmm/cordova-background-geolocation
```

## 6. Cambiar de scope o nombre

- **Scope:** edita `"name"` en `package.json` (p. ej. `@otro-usuario/cordova-background-geolocation`).
- **Versión:** actualiza `version` en `package.json` y la versión en `plugin.xml` antes de crear el Release.

Con esto puedes mantener tu fork publicado en npm y actualizarlo cada vez que crees un Release en GitHub.

---

## Si sigues teniendo 403 al publicar

El mensaje *"Two-factor authentication or granular access token with bypass 2fa enabled is required"* significa que el token que usas **no puede publicar sin 2FA**.

- **Token tipo "Publish" o "Read and Publish"** → npm sigue pidiendo 2FA en la cuenta. No basta con el token.
- **Solución 1:** Crear un token **Automation** (no "Publish"):
  1. [npmjs.com](https://www.npmjs.com/) → **Access Tokens** → **Generate New Token**.
  2. Selecciona **"Automation"** (o "Granular" con permiso de packages y opción **"Bypass two-factor authentication"**).
  3. Borra el token anterior de tu máquina:  
     `npm config delete //registry.npmjs.org/:_authToken`
  4. Configura el nuevo:  
     `npm config set //registry.npmjs.org/:_authToken=TU_NUEVO_TOKEN_AUTOMATION`
  5. `npm publish --access public`
- **Solución 2:** Activar **2FA** en la cuenta (Account settings → Add 2FA). Después, `npm login` (completa el flujo en el navegador con el código OTP) y luego `npm publish --access public` desde la terminal.
